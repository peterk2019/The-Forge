var structNVAPI__D3D12__PSO__RASTERIZER__STATE__DESC__V1 =
[
    [ "CoverageToColorEnable", "structNVAPI__D3D12__PSO__RASTERIZER__STATE__DESC__V1.html#a71850473f3fb146856ad327e84c0f989", null ],
    [ "CoverageToColorRTIndex", "structNVAPI__D3D12__PSO__RASTERIZER__STATE__DESC__V1.html#aaf39a1cc2d8dfae3f2364ac6856d21b9", null ],
    [ "ForcedSampleCount", "structNVAPI__D3D12__PSO__RASTERIZER__STATE__DESC__V1.html#a46fc9839deebba5a90f319b0aeb9e334", null ],
    [ "InterleavedSamplingEnable", "structNVAPI__D3D12__PSO__RASTERIZER__STATE__DESC__V1.html#a1595d79142f1ee002baec21cc09eb04e", null ],
    [ "PostZCoverageEnable", "structNVAPI__D3D12__PSO__RASTERIZER__STATE__DESC__V1.html#a5a00f5fc28b68417081d70c4f96ead36", null ],
    [ "ProgrammableSamplePositionsEnable", "structNVAPI__D3D12__PSO__RASTERIZER__STATE__DESC__V1.html#af56293b469627169c35f08965bcc770e", null ],
    [ "QuadFillMode", "structNVAPI__D3D12__PSO__RASTERIZER__STATE__DESC__V1.html#ae74d1a75b7edfd598acabaee7730d970", null ],
    [ "reserved", "structNVAPI__D3D12__PSO__RASTERIZER__STATE__DESC__V1.html#a2e62fdf7951144f96a9ac2669b9e6e73", null ],
    [ "SampleCount", "structNVAPI__D3D12__PSO__RASTERIZER__STATE__DESC__V1.html#ac25d87f5c08396db179e48a5856d1e7f", null ],
    [ "SamplePositionsX", "structNVAPI__D3D12__PSO__RASTERIZER__STATE__DESC__V1.html#acbd59777ba4947592168cd79deb839b3", null ],
    [ "SamplePositionsY", "structNVAPI__D3D12__PSO__RASTERIZER__STATE__DESC__V1.html#a8b0d8c765ec7cd8d0b40cf9af4fd450e", null ],
    [ "TargetIndepentRasterWithDepth", "structNVAPI__D3D12__PSO__RASTERIZER__STATE__DESC__V1.html#aefcbbfe5b216f9f7807bd9898f0b9a29", null ],
    [ "version", "structNVAPI__D3D12__PSO__RASTERIZER__STATE__DESC__V1.html#a11b52be0a178690da3b12708144d4284", null ]
];