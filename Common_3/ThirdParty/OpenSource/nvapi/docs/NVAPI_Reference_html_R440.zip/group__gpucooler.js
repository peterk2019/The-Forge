var group__gpucooler =
[
    [ "NvAPI_GPU_GetTachReading", "group__gpucooler.html#ga607a5e91f85d720a6b68375490b8b9df", null ]
];