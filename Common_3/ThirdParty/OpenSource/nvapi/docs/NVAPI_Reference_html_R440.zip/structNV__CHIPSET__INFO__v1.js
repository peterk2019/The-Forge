var structNV__CHIPSET__INFO__v1 =
[
    [ "deviceId", "structNV__CHIPSET__INFO__v1.html#ad8f3a0f40ed773106797cfeddb292b09", null ],
    [ "szChipsetName", "structNV__CHIPSET__INFO__v1.html#a88b712ac053f886e96177d1d362091c6", null ],
    [ "szVendorName", "structNV__CHIPSET__INFO__v1.html#ab12fbaee23f08c6736bb987186c0e77f", null ],
    [ "vendorId", "structNV__CHIPSET__INFO__v1.html#a54a82ea7853106c517ef4fa18128685e", null ],
    [ "version", "structNV__CHIPSET__INFO__v1.html#a9bc6893ef6c991249d39deee43dbdeae", null ]
];