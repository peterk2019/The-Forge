var structNV__D3D12__META__COMMAND__INITIALIZE__GEMM__DESC =
[
    [ "PersistentResource", "structNV__D3D12__META__COMMAND__INITIALIZE__GEMM__DESC.html#a959330b8a885d30c9f614e60865d6a34", null ]
];