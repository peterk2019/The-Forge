var structNVAPI__D3D12__PSO__ENABLE__DEPTH__BOUND__TEST__DESC__V1 =
[
    [ "EnableDBT", "structNVAPI__D3D12__PSO__ENABLE__DEPTH__BOUND__TEST__DESC__V1.html#a49feddcbfb5bdd4acdda21b6dccdfde3", null ],
    [ "version", "structNVAPI__D3D12__PSO__ENABLE__DEPTH__BOUND__TEST__DESC__V1.html#ad3606505bf56fa7cfcdef7e2f358cf11", null ]
];