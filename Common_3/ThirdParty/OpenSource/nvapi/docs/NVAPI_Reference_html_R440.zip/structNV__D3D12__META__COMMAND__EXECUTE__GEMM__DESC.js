var structNV__D3D12__META__COMMAND__EXECUTE__GEMM__DESC =
[
    [ "AResource", "structNV__D3D12__META__COMMAND__EXECUTE__GEMM__DESC.html#afdc5aa0da425c637d9386080464abd2c", null ],
    [ "BResource", "structNV__D3D12__META__COMMAND__EXECUTE__GEMM__DESC.html#ae78953adf0869a5336ada101fd4eb445", null ],
    [ "CResource", "structNV__D3D12__META__COMMAND__EXECUTE__GEMM__DESC.html#a9884fd7893bab631741a10e8a7b31231", null ],
    [ "OutputResource", "structNV__D3D12__META__COMMAND__EXECUTE__GEMM__DESC.html#ab4f3c4e6b50a7cc381e93d02ee45d635", null ],
    [ "PersistentResource", "structNV__D3D12__META__COMMAND__EXECUTE__GEMM__DESC.html#a7ece3d7f17a0efdc6d656e7192c78475", null ],
    [ "TemporaryResource", "structNV__D3D12__META__COMMAND__EXECUTE__GEMM__DESC.html#a2a18f6c396b0227ec2cfe2ba4e51c697", null ]
];