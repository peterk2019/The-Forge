var structNvAPI__D3D11__CREATE__DOMAIN__SHADER__EX__V3 =
[
    [ "NumCustomSemantics", "structNvAPI__D3D11__CREATE__DOMAIN__SHADER__EX__V3.html#abbe8ba22ff77c6de4f515e695aec503e", null ],
    [ "pCustomSemantics", "structNvAPI__D3D11__CREATE__DOMAIN__SHADER__EX__V3.html#a9dc1da4cd3112f3fb1aded81a90c8b97", null ],
    [ "UseSpecificShaderExt", "structNvAPI__D3D11__CREATE__DOMAIN__SHADER__EX__V3.html#ac6ac384bca4d011c94f16a8524ecb539", null ],
    [ "UseWithFastGS", "structNvAPI__D3D11__CREATE__DOMAIN__SHADER__EX__V3.html#ae7f9ab8fff196f59688c594ae92bbfcf", null ],
    [ "version", "structNvAPI__D3D11__CREATE__DOMAIN__SHADER__EX__V3.html#a4d7ed1df13327dc5ab40227fb7471103", null ]
];