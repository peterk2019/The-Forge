var group__gpuPerf =
[
    [ "NvAPI_GPU_GetPerfDecreaseInfo", "group__gpuPerf.html#ga5e6da89bd1ba2cb71ab6e2ef9228c451", null ]
];