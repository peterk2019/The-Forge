var structNV__GPU__CLIENT__ILLUM__DEVICE__SYNC__V1 =
[
    [ "bSync", "structNV__GPU__CLIENT__ILLUM__DEVICE__SYNC__V1.html#aa35e4eb8293bdaf7bff932505e5df413", null ],
    [ "rsvd", "structNV__GPU__CLIENT__ILLUM__DEVICE__SYNC__V1.html#a190fb326f94c536c83af20d817302a63", null ],
    [ "timeStampms", "structNV__GPU__CLIENT__ILLUM__DEVICE__SYNC__V1.html#ab4dfd7194685fa9e8aaba428b1c2308b", null ]
];