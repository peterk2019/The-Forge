var structNV__CUSTOM__DISPLAY =
[
    [ "colorFormat", "structNV__CUSTOM__DISPLAY.html#a315963bd6c3d9542e3f09d0b2f1822b2", null ],
    [ "depth", "structNV__CUSTOM__DISPLAY.html#a5b356d4a4c3f8994e10ecee6bc2caccf", null ],
    [ "height", "structNV__CUSTOM__DISPLAY.html#a0936ddb67575901649cbfbee518a6b3d", null ],
    [ "hwModeSetOnly", "structNV__CUSTOM__DISPLAY.html#a1ffb6fd72322a025e83de2016d3ceb2b", null ],
    [ "srcPartition", "structNV__CUSTOM__DISPLAY.html#ae3aabb5bc06fbcc8fe0d4f067223a109", null ],
    [ "timing", "structNV__CUSTOM__DISPLAY.html#acca30fb817070892303dd08c679459e9", null ],
    [ "version", "structNV__CUSTOM__DISPLAY.html#afb9e523b4c60e2c9ffc6d960ad830306", null ],
    [ "width", "structNV__CUSTOM__DISPLAY.html#af2e87954bdf268cef59cf09efc7bf2c2", null ],
    [ "xRatio", "structNV__CUSTOM__DISPLAY.html#af7beef279db2b776d5adc656b60f501f", null ],
    [ "yRatio", "structNV__CUSTOM__DISPLAY.html#a011a9e5c796b4e31b894292fde3fa142", null ]
];