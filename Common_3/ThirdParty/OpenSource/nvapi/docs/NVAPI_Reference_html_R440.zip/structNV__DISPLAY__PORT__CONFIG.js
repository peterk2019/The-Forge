var structNV__DISPLAY__PORT__CONFIG =
[
    [ "bpc", "structNV__DISPLAY__PORT__CONFIG.html#a60993df096caa13bf6e7bbf1774ea387", null ],
    [ "colorFormat", "structNV__DISPLAY__PORT__CONFIG.html#a5a4a59948a03f315f0d840502f0a0793", null ],
    [ "colorimetry", "structNV__DISPLAY__PORT__CONFIG.html#a00772663fac1bcabf651b0e2612613c5", null ],
    [ "dynamicRange", "structNV__DISPLAY__PORT__CONFIG.html#a50e169fabd67a69f99a6cb011029518e", null ],
    [ "isChromaLpfOff", "structNV__DISPLAY__PORT__CONFIG.html#aa1b7faae42d703b124164dc947322820", null ],
    [ "isDitherOff", "structNV__DISPLAY__PORT__CONFIG.html#a45328cc98c26f77c448006bad8a7afe6", null ],
    [ "isHPD", "structNV__DISPLAY__PORT__CONFIG.html#a641074a67367e2156926de91398f2878", null ],
    [ "isSetDeferred", "structNV__DISPLAY__PORT__CONFIG.html#a92159b72eda43e50344ab0a6d063cdcb", null ],
    [ "laneCount", "structNV__DISPLAY__PORT__CONFIG.html#a592430d0077f3c57c19bb189dc83b79f", null ],
    [ "linkRate", "structNV__DISPLAY__PORT__CONFIG.html#a9743c4312a455fc5631f48906b92053f", null ],
    [ "testColorChange", "structNV__DISPLAY__PORT__CONFIG.html#a2bf1851d078d4689c3eadd9161e51fff", null ],
    [ "testLinkTrain", "structNV__DISPLAY__PORT__CONFIG.html#ad1ae298cc89cce88cb6391772d2043d4", null ],
    [ "version", "structNV__DISPLAY__PORT__CONFIG.html#a2bb4560510e0bfb6b47db0846c1e8a2a", null ]
];