var structNV__SCANOUT__INTENSITY__DATA__V1 =
[
    [ "blendingTexture", "structNV__SCANOUT__INTENSITY__DATA__V1.html#a92bbd1c34aa576e8538f00b0949c6380", null ],
    [ "height", "structNV__SCANOUT__INTENSITY__DATA__V1.html#ab600bb6b2c1febad03b5b555b785299d", null ],
    [ "version", "structNV__SCANOUT__INTENSITY__DATA__V1.html#a2e098d043ff6f1668721635b1bf6fef2", null ],
    [ "width", "structNV__SCANOUT__INTENSITY__DATA__V1.html#a62955b51b5e6c972e35bb76780c92a97", null ]
];