var structNV__META__COMMAND__CONVOLUTION__FUSE__DESC =
[
    [ "OutputPrepool", "structNV__META__COMMAND__CONVOLUTION__FUSE__DESC.html#a733909753c7ddbeca03fd9c914f845f0", null ],
    [ "PoolMode", "structNV__META__COMMAND__CONVOLUTION__FUSE__DESC.html#ab189b4109b19954d76c05334215c3216", null ],
    [ "SkipMode", "structNV__META__COMMAND__CONVOLUTION__FUSE__DESC.html#a7c2f7cb61fb25a28a13eee818e9b9884", null ],
    [ "UpsampleMode", "structNV__META__COMMAND__CONVOLUTION__FUSE__DESC.html#a4de75082e98b727da8eff634178a6125", null ]
];