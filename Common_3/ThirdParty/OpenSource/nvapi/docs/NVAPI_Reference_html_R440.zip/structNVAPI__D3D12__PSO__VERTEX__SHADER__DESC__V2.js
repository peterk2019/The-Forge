var structNVAPI__D3D12__PSO__VERTEX__SHADER__DESC__V2 =
[
    [ "UseWithFastGS", "structNVAPI__D3D12__PSO__VERTEX__SHADER__DESC__V2.html#ab6a2d4f7f1c4f654f59ff634638fa139", null ]
];