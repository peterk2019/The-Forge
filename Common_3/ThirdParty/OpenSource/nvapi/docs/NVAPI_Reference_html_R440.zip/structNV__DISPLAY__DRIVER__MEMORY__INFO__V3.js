var structNV__DISPLAY__DRIVER__MEMORY__INFO__V3 =
[
    [ "availableDedicatedVideoMemory", "structNV__DISPLAY__DRIVER__MEMORY__INFO__V3.html#ab964e80ff3c44b1e1bfc2465dc30a6ce", null ],
    [ "curAvailableDedicatedVideoMemory", "structNV__DISPLAY__DRIVER__MEMORY__INFO__V3.html#afce936fac82659153de22519a87ee72e", null ],
    [ "dedicatedVideoMemory", "structNV__DISPLAY__DRIVER__MEMORY__INFO__V3.html#a03f490effe5516fa74d82144f3a77af1", null ],
    [ "dedicatedVideoMemoryEvictionCount", "structNV__DISPLAY__DRIVER__MEMORY__INFO__V3.html#a4f53618776fa4e2640b35aed3986174a", null ],
    [ "dedicatedVideoMemoryEvictionsSize", "structNV__DISPLAY__DRIVER__MEMORY__INFO__V3.html#a77af0e4fd6102e70a73df1e4e89db3e5", null ],
    [ "sharedSystemMemory", "structNV__DISPLAY__DRIVER__MEMORY__INFO__V3.html#a12191e512fc122b39ea34fde9d71b779", null ],
    [ "systemVideoMemory", "structNV__DISPLAY__DRIVER__MEMORY__INFO__V3.html#ac8451cf0e9384d1bdd9cd2f4d5315e36", null ],
    [ "version", "structNV__DISPLAY__DRIVER__MEMORY__INFO__V3.html#a4d3a342539574a75d1f3459ef2413789", null ]
];