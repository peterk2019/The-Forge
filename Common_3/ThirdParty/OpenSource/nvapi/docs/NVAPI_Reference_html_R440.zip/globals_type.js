var globals_type =
[
    [ "i", "globals_type.html", null ],
    [ "n", "globals_type_n.html", null ],
    [ "p", "globals_type_p.html", null ],
    [ "s", "globals_type_s.html", null ],
    [ "t", "globals_type_t.html", null ]
];