var nvapi__lite__sli_8h =
[
    [ "NV_GET_CURRENT_SLI_STATE_V2", "structNV__GET__CURRENT__SLI__STATE__V2.html", "structNV__GET__CURRENT__SLI__STATE__V2" ],
    [ "NV_GET_CURRENT_SLI_STATE", "nvapi__lite__sli_8h.html#a501ed9a6ea0a9b440ed32d647f3b1c6c", null ],
    [ "NV_GET_CURRENT_SLI_STATE_VER", "nvapi__lite__sli_8h.html#aacf8a080dcb54889295735ef01fed43d", null ],
    [ "NV_GET_CURRENT_SLI_STATE_VER1", "group__dx.html#ga3db7a2b29bc8bd5e75d9c52802fbb01d", null ],
    [ "NV_GET_CURRENT_SLI_STATE_VER2", "nvapi__lite__sli_8h.html#a0b36160725e13cebc10b1ff3b6d19b04", null ],
    [ "NVAPI_D3D_RESOURCERENDERING_FLAG", "group__dx.html#gada2f4fc6fff62bcf86666cf160caf478", null ],
    [ "NVAPI_D3D_SETRESOURCEHINT_CATEGORY", "group__dx.html#ga1965826ebf71dd9ec87e64668fcd1a76", null ],
    [ "NVAPI_D3D_SETRESOURCEHINT_SLI", "group__dx.html#ga2cb9c00a60c9b4eb5fe89bca552f7c21", null ],
    [ "_NVAPI_D3D_RESOURCERENDERING_FLAG", "group__dx.html#gacb556b0ac094f369cafd86ebdee7225e", [
      [ "NVAPI_D3D_RR_FLAG_DEFAULTS", "group__dx.html#ggacb556b0ac094f369cafd86ebdee7225eabbd49a773bb8923cc5a2df48a46a544e", null ],
      [ "NVAPI_D3D_RR_FLAG_FORCE_DISCARD_CONTENT", "group__dx.html#ggacb556b0ac094f369cafd86ebdee7225eabff256e5768334c0744fc608e6a10b11", null ],
      [ "NVAPI_D3D_RR_FLAG_FORCE_KEEP_CONTENT", "group__dx.html#ggacb556b0ac094f369cafd86ebdee7225ea436bdfceec698a98bfdd94418764a7b8", null ],
      [ "NVAPI_D3D_RR_FLAG_MULTI_FRAME", "group__dx.html#ggacb556b0ac094f369cafd86ebdee7225ea8667796bfa5d2a6ba654d5c09b0873b3", null ]
    ] ],
    [ "_NVAPI_D3D_SETRESOURCEHINT_CATEGORY", "group__dx.html#gaebde2545f7530a110de2c39e74d7c3f6", [
      [ "NVAPI_D3D_SRH_CATEGORY_SLI", "group__dx.html#ggaebde2545f7530a110de2c39e74d7c3f6aff9e6b54a91d6eb340aa814435d758df", null ]
    ] ],
    [ "_NVAPI_D3D_SETRESOURCEHINT_SLI", "group__dx.html#gaf5ad712e159c79512652c5ec353294c7", [
      [ "NVAPI_D3D_SRH_SLI_APP_CONTROLLED_INTERFRAME_CONTENT_SYNC", "group__dx.html#ggaf5ad712e159c79512652c5ec353294c7a1a3929d834678cafbf60c6c071b7d049", null ],
      [ "NVAPI_D3D_SRH_SLI_ASK_FOR_BROADCAST_USAGE", "group__dx.html#ggaf5ad712e159c79512652c5ec353294c7a42662c761d17a98fff812c5f2df74f58", null ],
      [ "NVAPI_D3D_SRH_SLI_RESPECT_DRIVER_INTERFRAME_CONTENT_SYNC", "group__dx.html#ggaf5ad712e159c79512652c5ec353294c7a038881a4bc38b2c3d7176ebe36cf4271", null ]
    ] ],
    [ "NvAPI_D3D_BeginResourceRendering", "group__dx.html#ga507241989bba7663ecc7754620977542", null ],
    [ "NvAPI_D3D_EndResourceRendering", "group__dx.html#gafdace4c7060784daf07b4d4929b9905c", null ],
    [ "NvAPI_D3D_GetCurrentSLIState", "group__dx.html#gabd5fb6089f050be1afb0de51d0bbadb0", null ],
    [ "NvAPI_D3D_SetResourceHint", "group__dx.html#gaadb25a20aa9073fc7656ef6fee312a7c", null ]
];