var structNvShaderExtnStruct =
[
    [ "dst0u", "structNvShaderExtnStruct.html#ad6bf8881c2279da37a7dccae7de93d13", null ],
    [ "dst1u", "structNvShaderExtnStruct.html#a0a6a7fd6ff8a8773d0092424bf18a707", null ],
    [ "markUavRef", "structNvShaderExtnStruct.html#a84be96d9e20a268462a04ef027a4346c", null ],
    [ "numOutputsForIncCounter", "structNvShaderExtnStruct.html#a51c724c61d9227695ab6a00921501de3", null ],
    [ "opcode", "structNvShaderExtnStruct.html#a425f011408841387ce92283ce7956724", null ],
    [ "padding1", "structNvShaderExtnStruct.html#af7691614a75c16b90e18cd4395561214", null ],
    [ "rid", "structNvShaderExtnStruct.html#a0cbbe6d0050fff7d0b6241f2cb962fd0", null ],
    [ "sid", "structNvShaderExtnStruct.html#a7765f6043c54c3e3b8405c9fff820993", null ],
    [ "src0u", "structNvShaderExtnStruct.html#a0f39bb826e9e78df21ffaf4577cdc8c8", null ],
    [ "src1u", "structNvShaderExtnStruct.html#afedd1698a6f00883f1dba6a3b7b786d9", null ],
    [ "src2u", "structNvShaderExtnStruct.html#a14d44ab32f309c8e6b8852dbb2be57a8", null ],
    [ "src3u", "structNvShaderExtnStruct.html#af2cb4341152bcf666167d69fca5ce36f", null ],
    [ "src4u", "structNvShaderExtnStruct.html#a9eac95427137485fada3d3a9beaaa191", null ],
    [ "src5u", "structNvShaderExtnStruct.html#aa418753ffe9a6512f63a33647052e427", null ]
];