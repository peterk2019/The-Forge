var structNV__MOSAIC__TOPO__DETAILS =
[
    [ "colCount", "structNV__MOSAIC__TOPO__DETAILS.html#a4dee9fc70a23d4b01f787f4cbece1168", null ],
    [ "displayOutputId", "structNV__MOSAIC__TOPO__DETAILS.html#a3abb0ee81bab8229de019a0c97283ca2", null ],
    [ "gpuLayout", "structNV__MOSAIC__TOPO__DETAILS.html#a6c714064fa2075c3614302d063632135", null ],
    [ "hLogicalGPU", "structNV__MOSAIC__TOPO__DETAILS.html#ae6a06ab3ecbbe4f438324d214079ce19", null ],
    [ "hPhysicalGPU", "structNV__MOSAIC__TOPO__DETAILS.html#a7ee188e26a61083911e2081359ad3ca1", null ],
    [ "overlapX", "structNV__MOSAIC__TOPO__DETAILS.html#a8b05f9df5dbf00ca0d520eb62a7d4545", null ],
    [ "overlapY", "structNV__MOSAIC__TOPO__DETAILS.html#af3fa94f0cc3655609b77d8c34558d3d6", null ],
    [ "rowCount", "structNV__MOSAIC__TOPO__DETAILS.html#ad685fb450887edb45033a9a7e27d828c", null ],
    [ "validityMask", "structNV__MOSAIC__TOPO__DETAILS.html#a469c1318a0419ee84fc7a247ef77127b", null ],
    [ "version", "structNV__MOSAIC__TOPO__DETAILS.html#a1cae9aa3d53a94269bc6cf616501a1e8", null ]
];