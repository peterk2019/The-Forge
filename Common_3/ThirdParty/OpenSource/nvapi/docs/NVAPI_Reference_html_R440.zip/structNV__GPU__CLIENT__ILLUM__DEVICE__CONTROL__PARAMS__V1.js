var structNV__GPU__CLIENT__ILLUM__DEVICE__CONTROL__PARAMS__V1 =
[
    [ "devices", "structNV__GPU__CLIENT__ILLUM__DEVICE__CONTROL__PARAMS__V1.html#a57fccba158d97908b9740a8fd2f4065d", null ],
    [ "numIllumDevices", "structNV__GPU__CLIENT__ILLUM__DEVICE__CONTROL__PARAMS__V1.html#ab18a21924c59f93354d4f1f44113441c", null ],
    [ "rsvd", "structNV__GPU__CLIENT__ILLUM__DEVICE__CONTROL__PARAMS__V1.html#aeee3556e9a0691dc3a37b506c1244414", null ],
    [ "version", "structNV__GPU__CLIENT__ILLUM__DEVICE__CONTROL__PARAMS__V1.html#ae6f5493d0ac0d5801e462d15ad190f39", null ]
];