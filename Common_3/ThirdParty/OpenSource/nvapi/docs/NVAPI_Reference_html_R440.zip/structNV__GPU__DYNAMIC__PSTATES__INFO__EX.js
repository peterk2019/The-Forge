var structNV__GPU__DYNAMIC__PSTATES__INFO__EX =
[
    [ "bIsPresent", "structNV__GPU__DYNAMIC__PSTATES__INFO__EX.html#a81e4755f0615f6022a5a48a120329ee0", null ],
    [ "flags", "structNV__GPU__DYNAMIC__PSTATES__INFO__EX.html#a763b5100d9670ba7ae21e9c33ef9ac4b", null ],
    [ "percentage", "structNV__GPU__DYNAMIC__PSTATES__INFO__EX.html#aceb3627616f6b19f925e5185b9af9e48", null ],
    [ "utilization", "structNV__GPU__DYNAMIC__PSTATES__INFO__EX.html#a7f26cd42fe2b056d4931ddddb9060ca3", null ],
    [ "version", "structNV__GPU__DYNAMIC__PSTATES__INFO__EX.html#a0970abc5ab24a13ebb0f97bc063551eb", null ]
];