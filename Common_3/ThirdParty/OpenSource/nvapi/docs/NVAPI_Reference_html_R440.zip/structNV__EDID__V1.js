var structNV__EDID__V1 =
[
    [ "EDID_Data", "structNV__EDID__V1.html#afb02e0659355703877a0b6feaca89b3e", null ],
    [ "version", "structNV__EDID__V1.html#a08a03513e6d620a4880dd86c985e2230", null ]
];