var group__disphandle =
[
    [ "NvAPI_DISP_GetAssociatedUnAttachedNvidiaDisplayHandle", "group__disphandle.html#ga7cac9587f2431fe42f6c1ff18aff6f73", null ],
    [ "NvAPI_EnumNvidiaDisplayHandle", "group__disphandle.html#ga7bc290301fbbae2faa166799e579858a", null ],
    [ "NvAPI_EnumNvidiaUnAttachedDisplayHandle", "group__disphandle.html#gaefe0334349f059f34b0ea1d3c33cc248", null ],
    [ "NvAPI_GetAssociatedNvidiaDisplayHandle", "group__disphandle.html#gae82d5dba9b3d980d3f260a86a15fab1c", null ]
];